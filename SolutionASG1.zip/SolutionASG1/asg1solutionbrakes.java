public final class Brakes extends Component{
    private static final ComponentName = new ComponentName("brakes");
    private static final ComponentType = new ComponentType("square");
    
    public Brakes(ComponentType type){
        SUPER(Name, type);
    }
    
    public Brakes(){
        this(DEFAULT TYPE);
    }

}