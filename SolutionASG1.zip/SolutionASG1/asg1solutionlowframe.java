public final class LowFrame extends Component{
    private static final ComponentName DEFAULT_NAME = new ComponentName("low frame");
    private static final ComponentType DEFAULT_TYPE = new ComponentType("shiny");
    
    public LowFrame(){
        super(DEFAULT_NAME, DEFAULT_TYPE);
    }
}