public final class Wheels extends Component{
    private static final ComponentName = new ComponentName("wheels");
    private static final ComponentType = new ComponentType("square");
    
    public Wheels(ComponentType type){
        SUPER(Name, type);
    }
    
    public wheels(){
        this(DEFAULT TYPE);
    }

}