/**
* Interface for representing an Animal habits
*
* @author Ana de Lorenzo-Caceres Luis(117106251)
*/
public interface Animal{
    public void eat( );
    public void roam( );
    public void makeNoise( );
}